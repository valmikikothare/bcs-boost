<footer class="frontendfooter">
   
    <div class="container-fluid p-0">
        <div class="row g-0">
            <div class="col-md-12">
                <div class="border-top text-center py-2">
                    <p class="text-light">{{ __('frontend.copy_right') }}</p>
                </div>
            </div>
        </div>
    </div>
</footer>