<!DOCTYPE html>
<html>
<head>
    <title>Session Reminder</title>
</head>
<body>
    <p>Dear User,</p>
    <p>This is a friendly reminder about your upcoming session scheduled in 2 days.</p>
    <p>Thank you!</p>
</body>
</html>
